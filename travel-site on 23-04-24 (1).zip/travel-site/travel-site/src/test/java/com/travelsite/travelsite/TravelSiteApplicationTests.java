package com.travelsite.travelsite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TravelSiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
