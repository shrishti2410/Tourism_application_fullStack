package com.travelsite.travelsite;

public class PackageInfo {
    private int packageId ;
    private String packageName;
    private String imageURL;

    public PackageInfo(int packageId, String packageName, String imageURL) {
        this.packageId = packageId;
        this.packageName = packageName;
        this.imageURL = imageURL;
    }

    public int getPackageId() {
        return packageId;
    }

    public String getPackageName() {
        return packageName;
    }

    public String getImageURL() {
        return imageURL;
    }
}
