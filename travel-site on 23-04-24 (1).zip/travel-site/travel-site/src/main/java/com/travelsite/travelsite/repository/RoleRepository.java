package com.travelsite.travelsite.repository;

import com.travelsite.travelsite.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role, Long> {
}
