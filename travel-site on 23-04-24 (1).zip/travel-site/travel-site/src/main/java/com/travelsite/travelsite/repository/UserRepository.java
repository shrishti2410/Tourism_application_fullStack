package com.travelsite.travelsite.repository;

import com.travelsite.travelsite.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User,Long> {
}
